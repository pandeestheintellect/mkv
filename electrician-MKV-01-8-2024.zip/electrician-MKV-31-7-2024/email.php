<?php

if(isset($_POST['send']))
{

    $from_user =$_POST['email'];
    $to="rajeowens@gmail.com"; //change to ur mail address
    $strSubject= "Enquiry from MKV Website";
 	$message = '<html><body>';
			$message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
			$message .= "<tr style='background: #eee;'><td><strong>Name:</strong> </td><td>" . strip_tags($_POST['name']) . "</td></tr>";
			$message .= "<tr><td><strong>Phone:</strong> </td><td>" . strip_tags($_POST['phone']) . "</td></tr>";
			
			
			$message .= "<tr><td><strong>Email:</strong> </td><td>" . strip_tags($_POST['email']) . "</td></tr>";
			$message .= "<tr><td><strong>Subject:</strong> </td><td>" . strip_tags($_POST['subject']) . "</td></tr>";
			
			
			$curText = htmlentities($_POST['message']);           
			if (($curText) != '') {
			    $message .= "<tr><td><strong>Requirement:</strong> </td><td>" . $curText . "</td></tr>";
			}
			$message .= "</table>";
			$message .= "</body></html>";
    $headers = 'MIME-Version: 1.0'."\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
    $headers .= "Bcc: rajeowens@gmail.com\r\n";
    $headers .= "From:".$from_user; 
    
    $mail_sent=mail($to, $strSubject, $message, $headers);  
    if($mail_sent)
        echo "<script>alert('Thank you. we will get back to you'); window.location='index.html';exit();</script>";
    else
        echo "<script>alert('Sorry.Request not send'); window.location='index.html';exit();</script>";
}
?>


